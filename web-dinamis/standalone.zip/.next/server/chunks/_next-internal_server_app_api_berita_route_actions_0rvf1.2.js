module.exports=[83293,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_berita_route_actions_0rvf1.2.js.map