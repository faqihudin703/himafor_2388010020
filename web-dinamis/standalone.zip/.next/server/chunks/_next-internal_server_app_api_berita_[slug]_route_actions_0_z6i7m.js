module.exports=[22395,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_berita_%5Bslug%5D_route_actions_0_z6i7m.js.map