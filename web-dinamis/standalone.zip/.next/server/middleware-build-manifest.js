globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/oR0Btd04hfPhIpEr6CMFo/_buildManifest.js",
    "static/oR0Btd04hfPhIpEr6CMFo/_ssgManifest.js",
    "static/oR0Btd04hfPhIpEr6CMFo/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0jrh_ej9o-lnh.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0bogtdbh.dcu1.js",
    "static/chunks/0vlfwkwqqd~xy.js",
    "static/chunks/turbopack-0e412l.jr1mum.js"
  ]
};
