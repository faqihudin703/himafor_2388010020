var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/kontak/route.js")
R.c("server/chunks/[root-of-the-server]__0_3g5o~._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_0z-nqy-._.js")
R.c("server/chunks/_next-internal_server_app_api_kontak_route_actions_0jvi7dk.js")
R.m(49707)
module.exports=R.m(49707).exports
