var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/berita/route.js")
R.c("server/chunks/[root-of-the-server]__0qwj2rn._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_0z-nqy-._.js")
R.c("server/chunks/_next-internal_server_app_api_berita_route_actions_0rvf1.2.js")
R.m(76708)
module.exports=R.m(76708).exports
