var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/berita/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__03c296r._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_0z-nqy-._.js")
R.c("server/chunks/_next-internal_server_app_api_berita_[slug]_route_actions_0_z6i7m.js")
R.m(31641)
module.exports=R.m(31641).exports
